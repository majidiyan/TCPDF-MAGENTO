<?php
class Mage_PDF_Helper_PickingList extends MDN_Orderpreparation_Helper_PickingList{
    public function getPdf() {
        //generate PDF depending of the method
        $mode = Mage::getStoreConfig('orderpreparation/picking_list/mode');
        if (!mage::getModel('Orderpreparation/ordertoprepare')->countOrders(MDN_Orderpreparation_Model_OrderToPrepare::filterSelected))
            throw new Exception('There is no orders in selected orders');

        if ($mode == MDN_Orderpreparation_Model_Source_PickingListMode::kMerged) {
            //merged mode, all products are displayed in the same document (mass picking) not implemented bt tcpdf
            return parent::getPdf();
        }
        //single document per order
        $orders = Mage::getModel('Orderpreparation/Ordertoprepare')->getSelectedOrders();
        $pdf = Tcpdf_Setup::getPDF();
        foreach ($orders as $order) {
            $obj = mage::getModel('mage_pdf/Pdf_OrderPreparationCommentsPdf');
            $obj->pdf = $pdf;
            $obj->getPdfWithMode($order, MDN_Orderpreparation_Model_Pdf_OrderPreparationCommentsPdf::MODE_ORDER_PREPRATION_SELECTED_TAB);
        }
        return $pdf;
    }
}
?>