<?php
if(!defined('DS')){
    define('DS',DIRECTORY_SEPARATOR);
}
/*
$data=array('نام مشتری',
    'استان - شهر',
    'آدرس',
    'کدپستی',
    'تلفن',
    'موبایل',
    'کد سفارش',
    'پیک پخش فینال'
);
*/
$customerName=isset($data[0])?$data[0]:'';
$region=isset($data[1])?$data[1]:'';
$street=isset($data[2])?$data[2]:'';
$postCode=isset($data[3])?$data[3]:'';
$phone=isset($data[4])?$data[4]:'';
$cell=isset($data[5])?$data[5]:'';
$orderNo=isset($data[6])?$data[6]:'';
$method=isset($data[7])?$data[7]:'';
//require_once(implode(DS,array(__DIR__,'lib','tcpdf','tcpdf.php')));
Tcpdf_Setup::getPDF();
$pdf = new TCPDF_Extended('L', 'mm', 'A5', true, 'UTF-8', false);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->SetDefaultMonospacedFont('courier');
$pdf->SetMargins(10,10,10);
$pdf->SetAutoPageBreak(TRUE, 5);
$lg = Array();
$lg['a_meta_charset'] = 'UTF-8';
$lg['a_meta_dir'] = 'rtl';
$lg['a_meta_language'] = 'fa';
$lg['w_page'] = 'page';

// set some language-dependent strings (optional)
$pdf->setLanguageArray($lg);
$pdf->AddPage();
$pdf->SetLineStyle(array('color' => array(0, 0, 0)));
$pdf->Line(5, 5, $pdf->getPageWidth()-5, 5);
$pdf->Line($pdf->getPageWidth()-5, 5, $pdf->getPageWidth()-5,  $pdf->getPageHeight()-5);
$pdf->Line(5, $pdf->getPageHeight()-5, $pdf->getPageWidth()-5, $pdf->getPageHeight()-5);
$pdf->Line(5, 5, 5, $pdf->getPageHeight()-5);
$pdf->SetCellPadding(1,1);
$pdf->SetFont('dejavusans', '', 30);
$pdf->SetLineStyle(array('color' => array(200, 200, 200)));
$pdf->MultiCell(70,20,'«احتیاط!»',1,'C',false,0,'','',true,0,false,true,20,'M');
$companyAddress=<<<ADDRESS
<div>فرستنده: شرکت هفت سین کالای ایرانیان<br />
آدرس: جاده قدیم قم، بعد از 60 متری شورآباد، خیابان دوم شرقی، کوچه هفتم، مرکز پخش فینال.<br />
صندوق پستی: 18165-165 کدپستی: 1818195356، تلفن 56543003</div>
ADDRESS;
$pdf->SetFont('dejavusans', '', 10);
$pdf->MultiCell(0,20,$companyAddress,1,'R',false,1,'','',true,0,true,true,20,'M');
$pdf->MultiCell(0,6,'خانم / آقا / شرکت','LR','R');
$pdf->SetFont('dejavusans', '', 30);
$pdf->MultiCell(0,18,$customerName,'LRB','C');
$pdf->SetFont('dejavusans', '', 10);
$pdf->MultiCell(0,6,'مقصد:','LR','R');
$pdf->SetFont('dejavusans', '', 20);
$pdf->MultiCell(0,14,$region,'LRB','C');
$pdf->SetFont('dejavusans', '', 12);
$address=<<<ADDRESS
<p>آدرس گیرنده:</p>
<p>%s - %s%s</p>
ADDRESS;
$pdf->MultiCell(95,25,sprintf($address,$region,$street,($postCode!==''?" {$postCode}":'')),0,'R',false,0,'','',true,0,true,true,20);
$shippingMethod=<<<METHOD
<p>نحوه ارسال:</p>
<p>%s</p>
METHOD;
$pdf->setCellPaddings(1,1,8,1);
$pdf->MultiCell(95,25,sprintf($shippingMethod,$method),0,'R',false,1,'','',true,0,true,true,20);
$additional=<<<ADDITIONAL
نام گیرنده: %s\r\n
کدپستی: %s\r\n
تلفن: %s\r\n
همراه: %s\r\n
کد سفارش: %s\r\n
ADDITIONAL;
$pdf->setCellPaddings(1,1,1,1);
$pdf->SetFont('dejavusans', '', 10);
$pdf->setCellHeightRatio(0.8);
$pdf->MultiCell(95,40,sprintf($additional,$customerName,$postCode,$phone,$cell,$orderNo),0,'R',false,0,'','',true,0,FALSE,true,40,'B');
$notice='در صورت مخدوش بودن بسته از دریافت آن خودداری فرمایید';
$pdf->setCellPaddings(1,3,1,3);
$pdf->setCellMargins('',10);
$pdf->SetLineStyle(array('color' => array(0, 0, 0)));
$pdf->MultiCell(95,7,$notice,1,'C');
$style['position'] = 'L';
$pdf->write1DBarcode($orderNo, 'C128A', '', '', '', 18, 0.4, $style, 'N');
$pdfFile=$csvFile.'.pdf';
$pdf->Output($csvFile.'.pdf', 'i');
echo $pdfFile;
?>