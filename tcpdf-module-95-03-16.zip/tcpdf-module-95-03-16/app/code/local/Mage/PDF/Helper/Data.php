<?php
class Mage_PDF_Helper_Data extends Mage_Core_Helper_Data{
    const PICKING = 'picking';
}