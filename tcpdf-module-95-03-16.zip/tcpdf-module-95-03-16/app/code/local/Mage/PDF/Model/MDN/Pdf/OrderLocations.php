<?php
class Mage_PDF_Model_MDN_Pdf_OrderLocations extends MDN_Purchase_Model_Pdf_OrderLocations{
    public function getPdf($orders = array()) {
        $this->initLocale($orders);

        $this->_beforeGetPdf();
        $this->_initRenderer('invoice');

        if ($this->pdf == null){
            $this->pdf = Tcpdf_Setup::getPDF();
        }else{
            $this->firstPageIndex = $this->pdf->getAliasNbPages();
        }
        $this->pdf->SetFont('dejavusans', '', 10);

        foreach ($orders as $order) {

            //add new page
            $titre = mage::helper('purchase')->__('Purchase Order');
            $this->pdf->setHeaderFont(array('dejavusans', '', 10));
            $this->pdf->setHeaderData('',0,Mage::getStoreConfig('purchase/general/header_text', 0));
            $this->pdf->setCellPaddings(1, 3, 1, 3);
            //$this->pdf->setCellMargins(1, 0, 1, 0);
            $this->pdf->AddPage();
            $this->pdf->Cell(0, 0, $titre, 'B', 1, 'C', 0, '', 0);

            //page header
            $txt_date = mage::helper('mage_all')->__('Date :  ') . date('d/m/Y', strtotime($order->getpo_date()));
            $txt_order = mage::helper('mage_all')->__('No : ') . $order->getpo_order_id();
            $pageWidth=$this->pdf->getPageWidth()-30;
            $halfWidth=$pageWidth/2;
            $this->pdf->MultiCell($halfWidth, 0, $txt_order, 'TBL', 'C', 0, 0, '', '', true);
            $this->pdf->MultiCell($halfWidth, 0, $txt_date, 'TBR','C', 0, 1, '', '', true);
            $adresse_fournisseur = $order->getSupplier()->getAddressAsText();
            $adresse_client = $order->getTargetWarehouse()->getstock_address();
            $this->pdf->MultiCell($halfWidth, 38, $adresse_fournisseur, 'TBL', 'R', 0, 0, '', '', true);
            $this->pdf->MultiCell($halfWidth, 38, $adresse_client, 'TBR','R', 0, 1, '', '', true);

            //table header
            $this->pdf->MultiCell(0.1*$pageWidth, 0, Mage::helper('purchase')->__('Location'),'B', 'R', 0, 0, '', '', true);
            $this->pdf->MultiCell(0.15*$pageWidth, 0, Mage::helper('purchase')->__('Qty'), 'B','R', 0, 0, '', '', true);
            $this->pdf->MultiCell(0.15*$pageWidth, 0, Mage::helper('purchase')->__('Sku'), 'B', 'R', 0, 0, '', '', true);
            $this->pdf->MultiCell(0.6*$pageWidth, 0, Mage::helper('purchase')->__('Product'), 'B','R', 0, 1, '', '', true);
            $warehouse = $order->getTargetWarehouse();

            //first loop to store location & product information
            $products = array();
            foreach ($order->getProducts() as $item) {
                $product = array();

                $product['location'] = $warehouse->getProductLocation($item->getpop_product_id());
                $product['sku'] = $item->getSku();
                $product['name'] = $item->getpop_product_name();
                $product['qty'] = $item->getpop_qty();

                $products[] = $product;
            }

            //sort by location
            usort($products, array("MDN_Purchase_Model_Pdf_OrderLocations", "sortProductsPerLocation"));

            //Display products
            foreach ($products as $item) {
                $page_start = $this->pdf->getPage();
                $y_start = $this->pdf->GetY();
                //location
                $this->pdf->MultiCell(0.1*$pageWidth, 0, $item['location'],'B', 'R', 0, 0, '', '', true);
                $page_end_1 = $this->pdf->getPage();
                $y_end_1 = $this->pdf->GetY();
                $this->pdf->setPage($page_start);

                //qty
                $this->pdf->MultiCell(0.15*$pageWidth, 0, $item['qty'],'B', 'R', 0, 0, '', '', true);
                $page_end_2 = $this->pdf->getPage();
                $y_end_2 = $this->pdf->GetY();
                $this->pdf->setPage($page_start);

                //sku
                $this->pdf->MultiCell(0.15*$pageWidth, 0, $item['sku'],'B', 'R', 0, 0, '', '', true);
                $page_end_3 = $this->pdf->getPage();
                $y_end_3 = $this->pdf->GetY();
                $this->pdf->setPage($page_start);

                //name
                $this->pdf->MultiCell(0.6*$pageWidth, 0, $item['name'], 'B','R', 0, 1, '', '', true);
                $page_end_4 = $this->pdf->getPage();
                $y_end_4 = $this->pdf->GetY();
                $this->pdf->setPage($page_start);

                //new page if required
                $newPage=max($page_end_1,$page_end_2,$page_end_3,$page_end_4);
                if (max($page_end_1,$page_end_2,$page_end_3,$page_end_4) == $page_start) {
                    $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4);
                } elseif (max($page_end_1, $page_end_2, $page_end_3, $page_end_4)==min($page_end_1, $page_end_2, $page_end_3, $page_end_4)) {
                    $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4);
                } elseif ($page_end_1 > $page_end_2) {
                    $ynew = $y_end_1;
                } else {
                    $tempArray=array(1=>$page_end_1,
                        2=>$page_end_2,
                        3=>$page_end_3,
                        4=>$page_end_4);
                    $key=array_search($newPage,$tempArray);
                    $name='y_end_'.$key;
                    $ynew = $$name;
                }
                $this->pdf->setPage($newPage);
                $this->pdf->SetXY($this->pdf->GetX(),$ynew);

            }
        }

        //reset language
        Mage::app()->getLocale()->revert();
        return $this->pdf;
    }
}
?>