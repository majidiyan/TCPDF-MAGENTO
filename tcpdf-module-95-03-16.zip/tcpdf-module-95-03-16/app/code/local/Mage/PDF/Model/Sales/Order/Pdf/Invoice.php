<?php
class Mage_PDF_Model_Sales_Order_Pdf_Invoice extends Mage_Sales_Model_Order_Pdf_Invoice{
    /**
     * @var Mage_All_Helper_Data
     */
    protected $helperMage=null;
    /**
     * @var TCPDF_Extended
     */
    protected function __($text){
        if(is_null($this->helperMage)){
            $this->helperMage=Mage::helper('mage_all');
        }
        return $this->helperMage->__($text);
    }

    public function getSku($item)
    {
        if ($item->getOrderItem()->getProductOptionByCode('simple_sku'))
            return $item->getOrderItem()->getProductOptionByCode('simple_sku');
        else
            return $item->getSku();
    }

    protected function _drawHeader($pdf)
    {
        /* Add table head */

        //columns headers
        $lines=array();
        $lines[] = array(
            'text' => Mage::helper('sales')->__('Products'),
            'feed' => 64
        );

        $lines[] = array(
            'text'  => Mage::helper('sales')->__('SKU'),
            'feed'  => 17,
            'align' => 'R'
        );

        $lines[] = array(
            'text'  => Mage::helper('sales')->__('Qty'),
            'feed'  => 17,
            'align' => 'R'
        );

        $lines[] = array(
            'text'  => Mage::helper('sales')->__('Price'),
            'feed'  => 27,
        );

        $lines[] = array(
            'text'  => Mage::helper('sales')->__('Tax'),
            'feed'  => 25,
        );

        $lines[] = array(
            'text'  => Mage::helper('sales')->__('Subtotal'),
            'feed'  => 30,
        );
        $titles=count($lines);
        $pdf->setCellPaddings(1, 3, 1, 3);
        $pdf->setCellMargins(0, 3, 0, 0);
        for($i=0;$i<$titles; $i++){
            $pdf->MultiCell($lines[$i]['feed'], 8, $lines[$i]['text'], 'TB'.($i===0?'R':($i+1===$titles?'L':'')), 'R', 0, $i+1===$titles?1:0, '', '', true);
        }
    }

    protected function _drawItem(Varien_Object $item, $pdf, Mage_Sales_Model_Order $order, $addBottom=false)
    {
        $lines=array();
        $lines[0] = array(
            'text' => $item->getName(),
            'feed' => 64,
        );

        // draw SKU
        $lines[1] = array(
            'text'  => $this->getSku($item),
            'feed'  => 17
        );

        // draw QTY
        $lines[2] = array(
            'text'  => intval($item->getQty()),
            'feed'  => 17
        );

        // draw item Prices
        if (Mage::helper('tax')->displaySalesBothPrices()) {
            $prices = array(
                array(
                    'label'    => Mage::helper('tax')->__('Excl. Tax') . ':',
                    'price'    => $order->formatPriceTxt($item->getPrice()),
                    'subtotal' => $order->formatPriceTxt($item->getRowTotal())
                ),
                array(
                    'label'    => Mage::helper('tax')->__('Incl. Tax') . ':',
                    'price'    => $order->formatPriceTxt($item->getPriceInclTax()),
                    'subtotal' => $order->formatPriceTxt($item->getRowTotalInclTax())
                ),
            );
        } elseif (Mage::helper('tax')->displaySalesPriceInclTax()) {
            $prices = array(array(
                'price' => $order->formatPriceTxt($item->getPriceInclTax()),
                'subtotal' => $order->formatPriceTxt($item->getRowTotalInclTax()),
            ));
        } else {
            $prices = array(array(
                'price' => $order->formatPriceTxt($item->getPrice()),
                'subtotal' => $order->formatPriceTxt($item->getRowTotal()),
            ));
        }
        $lines[3]=array('text'  => '', 'feed'  => '');
        $lines[5]=array('text'  => '', 'feed'  => '');;
        foreach ($prices as $priceData){
            // draw Price
            $price=$priceData['price'];
            $price=str_replace(',00','',$price);
            $price=str_replace('.','',$price);
            $lines[3] = array(
                'text'  => $lines[3]['text'].($lines[3]['text']===''?'':"\r\n").$price,
                'feed'  => 27
            );
            // draw Subtotal
            $price=$priceData['subtotal'];
            $price=str_replace(',00','',$price);
            $price=str_replace('.','',$price);
            $lines[5] = array(
                'text'  => $lines[5]['text'].($lines[5]['text']===''?'':"\r\n").$price,
                'feed'  => 30
            );
        }

        // draw Tax
        $price=$order->formatPriceTxt($item->getTaxAmount());
        $price=str_replace(',00','',$price);
        $price=str_replace('.','',$price);
        $lines[4] = array(
            'text'  => $price,
            'feed'  => 25
        );
        $pdf->setCellPaddings(1, 3, 1, 3);
        $pdf->setCellMargins(0, 0, 0, 0);
        $items=count($lines);
        for($i=0;$i<$items; $i++){
            $pdf->MultiCell($lines[$i]['feed'], 8, $lines[$i]['text'], ($addBottom?'B':'').($i===0?'R':($i+1===$items?'L':'')), 'R', 0, $i+1===$items?1:0, '', '', true);
        }
    }

    protected function insertOrder(&$pdf, $obj, $putOrderId = true)
    {
        if ($obj instanceof Mage_Sales_Model_Order) {
            $shipment = null;
            $order = $obj;
        } elseif ($obj instanceof Mage_Sales_Model_Order_Shipment) {
            $shipment = $obj;
            $order = $shipment->getOrder();
        }
        if ($putOrderId) {
            $pdf->writeHTMLCell(0, 0, '', '', sprintf('<p>%s %s</p>',Mage::helper('sales')->__('Order # '), $order->getRealOrderId()), 0, 1, 0, true, '', true);
        }
        $dateText=Mage::helper('sales')->__('Order Date: ') . Mage::helper('core')->formatDate(
                $order->getCreatedAtStoreDate(), 'medium', false
            );
        $pdf->writeHTMLCell(0, 0, '', '', sprintf('<p>%s</p>',$dateText, $order->getRealOrderId()), 0, 1, 0, true, '', true);

        /* Billing Address */
        $billingAddress = $this->_formatAddress($order->getBillingAddress()->format('pdf'));

        /* Payment */
        $paymentInfo = Mage::helper('payment')->getInfoBlock($order->getPayment())
            ->setIsSecureMode(true)
            ->toPdf();
        $paymentInfo = htmlspecialchars_decode($paymentInfo, ENT_QUOTES);
        $payment = explode('{{pdf_row_separator}}', $paymentInfo);
        foreach ($payment as $key=>$value){
            if (strip_tags(trim($value)) == '') {
                unset($payment[$key]);
            }
        }
        reset($payment);

        /* Shipping Address and Method */
        if (!$order->getIsVirtual()) {
            /* Shipping Address */
            $shippingAddress = $this->_formatAddress($order->getShippingAddress()->format('pdf'));
            $shippingMethod  = $order->getShippingDescription();
        }
        $temp='';
        foreach ($billingAddress as $value){
            if ($value !== '') {
                $text = array();
                foreach (Mage::helper('core/string')->str_split($value, 45, true, true) as $_value) {
                    $text[] = $_value;
                }
                foreach ($text as $part) {
                    $temp.=($temp===''?'':"\r\n").strip_tags(ltrim($part));
                }
            }
        }
        $style = array('color' => array(100, 100, 100));
        $pdf->SetLineStyle($style);
        $pdf->setCellPaddings(1, 3, 1, 3);
        $pdf->setCellMargins(0, 3, 0, 0);
        $RightAddress=Mage::helper('sales')->__('Sold to:')."\r\n".$temp;
        $pdf->MultiCell(90, 35, $RightAddress, 1, 'R', 0, 0, '', '', true);
        if (!$order->getIsVirtual()) {
            $temp='';
            foreach ($shippingAddress as $value){
                if ($value!=='') {
                    $text = array();
                    foreach (Mage::helper('core/string')->str_split($value, 45, true, true) as $_value) {
                        $text[] = $_value;
                    }
                    foreach ($text as $part) {
                        $temp.=($temp===''?'':"\r\n").strip_tags(ltrim($part));
                    }
                }
            }
            $LeftAddress=Mage::helper('sales')->__(!$order->getIsVirtual()? 'Ship to:':'Payment Method:')."\r\n".$temp;
            $pdf->MultiCell(90, 35, $LeftAddress, 1, 'R', 0, 1, '', '', true);
            $pdf->setCellMargins(0, 0, 0, 0);

            $temp='';
            foreach ($payment as $value){
                if (trim($value) != '') {
                    //Printing "Payment Method" lines
                    $value = preg_replace('/<br[^>]*>/i', "\n", $value);
                    foreach (Mage::helper('core/string')->str_split($value, 45, true, true) as $_value) {
                        $temp.=($temp===''?'':"\r\n").strip_tags(trim($_value));
                    }
                }
            }

            $RightAddress=Mage::helper('sales')->__('Payment Method:')."\r\n".$temp;
            $pdf->MultiCell(90, 20, $RightAddress, 1, 'R', 0, 0, '', '', true);


            $temp='';
            foreach (Mage::helper('core/string')->str_split($shippingMethod, 45, true, true) as $_value) {
                $temp.=($temp===''?'':"\r\n").strip_tags(trim($_value));
            }
            $totalShippingChargesText = "(" . Mage::helper('sales')->__('Total Shipping Charges') . " "
                . $order->formatPriceTxt($order->getShippingAmount()) . ")";

            $temp.=($temp===''?'':"\r\n").$totalShippingChargesText;

            $tracks = array();
            if ($shipment) {
                $tracks = $shipment->getAllTracks();
            }
            if (count($tracks)) {
/**@TODO baray baad
                $this->_setFontRegular($page, 9);
                $page->setFillColor(new Zend_Pdf_Color_GrayScale(0));
                //$page->drawText(Mage::helper('sales')->__('Carrier'), 290, $yShipments - 7 , 'UTF-8');
                $page->drawText(Mage::helper('sales')->__('Title'), 290, $yShipments - 7, 'UTF-8');
                $page->drawText(Mage::helper('sales')->__('Number'), 410, $yShipments - 7, 'UTF-8');

                $yShipments -= 20;
                $this->_setFontRegular($page, 8);
                foreach ($tracks as $track) {

                    $CarrierCode = $track->getCarrierCode();
                    if ($CarrierCode != 'custom') {
                        $carrier = Mage::getSingleton('shipping/config')->getCarrierInstance($CarrierCode);
                        $carrierTitle = $carrier->getConfigData('title');
                    } else {
                        $carrierTitle = Mage::helper('sales')->__('Custom Value');
                    }

                    //$truncatedCarrierTitle = substr($carrierTitle, 0, 35) . (strlen($carrierTitle) > 35 ? '...' : '');
                    $maxTitleLen = 45;
                    $endOfTitle = strlen($track->getTitle()) > $maxTitleLen ? '...' : '';
                    $truncatedTitle = substr($track->getTitle(), 0, $maxTitleLen) . $endOfTitle;
                    //$page->drawText($truncatedCarrierTitle, 285, $yShipments , 'UTF-8');
                    $page->drawText($truncatedTitle, 292, $yShipments , 'UTF-8');
                    $page->drawText($track->getNumber(), 410, $yShipments , 'UTF-8');
                    $yShipments -= $topMargin - 5;
                }*/
            }
            $LeftAddress=Mage::helper('sales')->__('Shipping Method:')."\r\n".$temp;;
            $pdf->MultiCell(90, 20, $LeftAddress, 1, 'R', 0, 1, '', '', true);
            return;
        }
        else {
        }
    }


    public function getPdf($invoices = array()){
        $this->_beforeGetPdf();
        $this->_initRenderer('invoice');
        $pdf = Tcpdf_Setup::getPDF();
        $this->_setPdf($pdf);
        $pdf->SetFont('dejavusans', '', 10);
        foreach ($invoices as $invoice) {
            if ($invoice->getStoreId()) {
                Mage::app()->getLocale()->emulate($invoice->getStoreId());
                Mage::app()->setCurrentStore($invoice->getStoreId());
            }
            $pdf->AddPage();
            $order = $invoice->getOrder();
            /* Add image */
            //------------------$this->insertLogo($page, $invoice->getStore());
            /* Add address */
            //$this->insertAddress($pdf, $invoice->getStore());
            //return $pdf;
            /* Add head */
            $pdf->writeHTMLCell(0, 0, '', 20, sprintf('<p>%s %s</p>',Mage::helper('sales')->__('Invoice # '), $invoice->getIncrementId()), 0, 1, 0, true, '', true);
            $this->insertOrder(
                $pdf,
                $order,
                Mage::getStoreConfigFlag(self::XML_PATH_SALES_PDF_INVOICE_PUT_ORDER_ID, $order->getStoreId())
            );
            /* Add document text and number */
            $pdf->SetFont('dejavusans', '', 8);
            /* Add table */
            $this->_drawHeader($pdf);
            /* Add body */
            foreach ($invoice->getAllItems() as $item){
                if ($item->getOrderItem()->getParentItem()) {
                    continue;
                }
                /* Draw item */
                $this->_drawItem($item, $pdf, $order);
                $newPage=$pdf->getPage();
                $pdf->setPage($newPage);
                $pdf->SetXY($pdf->GetX(),$pdf->GetY());
            }
            $pdf->MultiCell(180, 5, '', 'T', 'R',0, 1, '', '', true);

            /* Add totals */
            $order = $invoice->getOrder();
            $totals = $this->_getTotalsList($invoice);
            foreach ($totals as $total) {
                $total->setOrder($order)
                    ->setSource($invoice);

                if ($total->canDisplay()) {
                    $total->setFontSize(10);
                    $lines=array();
                    foreach ($total->getTotalsForDisplay() as $totalData) {
                        $lines[] = array(
                                'label'      => $totalData['label'],
                                'text'      => $totalData['amount']
                        );
                    }
                }
            }
            $pdf->SetFont('dejavusans', '', 9);
            $pdf->setCellMargins(0, 3, 0, 0);
            foreach($lines as $line){
                $pdf->MultiCell(120, 5, $line['label'], 0, 'L',0, 0, '', '', true);
                $price=$line['text'];
                $price=str_replace(',00','',$price);
                $price=str_replace('.','',$price);
                $pdf->MultiCell(60, 5, $price, 0, 'R',0, 1, '', '', true);
            }



            if ($invoice->getStoreId()) {
                Mage::app()->getLocale()->revert();
            }
        }
        $this->_afterGetPdf();
        return $pdf;
    }
}