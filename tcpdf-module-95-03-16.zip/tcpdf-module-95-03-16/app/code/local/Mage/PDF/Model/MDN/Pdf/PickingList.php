<?php

/**
 * Generate PDF for picking list
 *
 */
class Mage_PDF_Model_MDN_Pdf_PickingList extends MDN_Orderpreparation_Model_Pdf_PickingList {
    /**
     * @var Mage_All_Helper_Data
     */
    protected $helperMage=null;
    /**
     * @var TCPDF_Extended
     */
    public $pdf;
    protected function __($text){
        if(is_null($this->helperMage)){
            $this->helperMage=Mage::helper('mage_all');
        }
        return $this->helperMage->__($text);
    }
    public function AddAddressesBlock($pdf, $LeftAddress, $RightAddress, $TxtDate, $TxtInfo) {
        //reformate les adresse pour qu'elle tiennent dans la largeur
        //$RightAddress = $this->WrapTextToWidth($page, $RightAddress, 600);
        //barre grise verticale pour s�parer les adresses
        $html=sprintf('<p>%s</p><p>%s</p>',$TxtDate,$TxtInfo);
        $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        $pdf->writeHTMLCell(0, 0, '', '45', '<hr />', 0, 1, 0, true, '', true);
        $pdf->setCellPaddings(1, 3, 1, 3);
        $pdf->setCellMargins(1, 0, 1, 0);
        $pdf->MultiCell(85, 0, $RightAddress, 0, 'R', 0, 0, '', '', true);
        $pdf->MultiCell(85, 0, $LeftAddress, 0, 'R', 0, 1, '', '', true);
        $pdf->writeHTMLCell(0, 0, '', '', '<hr />', 0, 1, 0, true, '', true);
    }

    public function drawTableHeader(&$pdf) {

        //entetes de colonnes
        $header=array(
            array(Mage::helper('purchase')->__('Quantity'),15),
            array(Mage::helper('purchase')->__('Name'),121),
            array(Mage::helper('purchase')->__('Location'),45)
        );
        $pdf->setCellMargins(0, 0, 0, 0);
        $num_headers=count($header);
        for($i = 0; $i < $num_headers; ++$i) {
            //$pdf->Cell(45, 7, $header[$i], 1, 0, 'C', false);
            $pdf->MultiCell($header[$i][1],7,$header[$i][0],0,$i<2?'R':'C',0,0);
        }
        $pdf->Ln();
    }
    public function getPdf($data = array()) {
        $this->_beforeGetPdf();
        $this->_initRenderer('invoice');

        //init datas
        $comments = $data['comments'];
        $products = $data['products'];

        //init pdf object
        if ($this->pdf == null){
            $this->pdf = Tcpdf_Setup::getPDF();
        }


        //create new page
        $titre = mage::helper('purchase')->__('Picking List');
        $this->pdf->setHeaderFont(array('dejavusans', '', 8));
        $this->pdf->SetHeaderData('', 0, $titre);
        $this->pdf->SetFont('dejavusans', '', 10);
        $this->pdf->AddPage();

        //display comments
        if ($comments) {
            $html=sprintf('<p>%s</p><hr />',$comments);
            $this->pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        }

        //display table header
        $this->drawTableHeader($this->pdf);
        $this->pdf->setCellPaddings('',3,'',3);
        foreach ($products as $product) {
            $page_start = $this->pdf->getPage();
            $y_start = $this->pdf->GetY();

            $page_end_1 = $this->pdf->getPage();
            $y_end_1 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);
            //qty
            $this->pdf->MultiCell(15,8,((string)$product['qty']),array('T'=>array(1)),'R',0,0);
            $page_end_2 = $this->pdf->getPage();
            $y_end_2 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);

            //add product information
            $manufacturerText = $product['manufacturer'];
            if ($manufacturerText)
                $caption = $manufacturerText . ' - ' . $product['sku'];
            else
                $caption = $product['sku'];
            $caption = sprintf('%s (%s)',$product['name'],$caption);

            $caption .= mage::helper('AdvancedStock/Product_ConfigurableAttributes')->getDescription($product->getId());
            $this->pdf->MultiCell(121,8,$pre.$caption,array('T'=>array(1)),'R',0,0);
            $page_end_3 = $this->pdf->getPage();
            $y_end_3 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);

            //add barcode picture and location
            /*if ($product['barcode']) {
                try{
                    $picture = mage::helper('AdvancedStock/Product_Barcode')->getBarcodePicture($product['barcode']);
                    if ($picture) {
                        $zendPicture = $this->pngToZendImage($picture);
                        $page->drawImage($zendPicture, self::X_POS_BARCODE, $this->y - 15, self::X_POS_BARCODE + self::WIDTH_BARCODE, $this->y - 15 + 30);
                    }
                }catch(Exception $ex){
                    mage::logException($ex);
                }
            }*/

            //Draw location
            $this->pdf->MultiCell(45,8,$product['location'],array('T'=>array(1)),'R',0);
            $page_end_4 = $this->pdf->getPage();
            $y_end_4 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);



            // logic
            $newPage=max($page_end_1,$page_end_2,$page_end_3,$page_end_4);
            if (max($page_end_1,$page_end_2,$page_end_3,$page_end_4) == $page_start) {
                $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4);
            } elseif (max($page_end_1, $page_end_2, $page_end_3, $page_end_4)==min($page_end_1, $page_end_2, $page_end_3, $page_end_4)) {
                $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4);
            } elseif ($page_end_1 > $page_end_2) {
                $ynew = $y_end_1;
            } else {
                $tempArray=array(1=>$page_end_1,
                    2=>$page_end_2,
                    3=>$page_end_3,
                    4=>$page_end_4);
                $key=array_search($newPage,$tempArray);
                $name='y_end_'.$key;
                $ynew = $$name;
            }
            $this->pdf->setPage($newPage);
            $this->pdf->SetXY($this->pdf->GetX(),$ynew);
        }
        return $this->pdf;
        //draw footer
        $this->drawFooter($page);

        //draw pager
        $this->AddPagination($this->pdf);

        $this->_afterGetPdf();

        return $this->pdf;
    }

}

