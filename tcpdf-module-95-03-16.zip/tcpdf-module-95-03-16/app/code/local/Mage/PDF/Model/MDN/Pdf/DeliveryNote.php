<?php
class Mage_PDF_Model_MDN_Pdf_DeliveryNote extends MDN_Purchase_Model_Pdf_DeliveryNote{
    private $_date = null;
    private $_po = null;

    public function getPdfForDate($po, $date)
    {
        $this->_date = $date;
        $this->_po = $po;

        $lines = Mage::getSingleton('Purchase/Order_Delivery')->getDeliveredProducts($po, $date);

        return $this->getPdf($lines);
    }

    public function getPdf($lines = array()) {
        $this->_beforeGetPdf();
        $this->_initRenderer('invoice');

        if ($this->pdf == null){
            $this->pdf = Tcpdf_Setup::getPDF();
        }else{
            $this->firstPageIndex = $this->pdf->getAliasNbPages();
        }
        $this->pdf->SetFont('dejavusans', '', 10);

        //add new page
        $this->pdf->setHeaderFont(array('dejavusans', '', 10));
        $this->pdf->setHeaderData('',0,Mage::getStoreConfig('purchase/general/header_text', 0));
        $this->pdf->setCellPaddings(1, 3, 1, 3);
        $this->pdf->AddPage();
        $titre=mage::helper('purchase')->__('PO %s delivery : %s', $this->_po->getpo_order_id(), Mage::helper('core')->formatDate($this->_date, 'short', false));
        $this->pdf->Cell(0, 0, $titre, 'B', 1, 'C', 0, '', 0);

        $pageWidth=$this->pdf->getPageWidth()-30;

        //table header
        $this->pdf->MultiCell(0.1*$pageWidth, 0, Mage::helper('purchase')->__('Qty'),'B', 'R', 0, 0, '', '', true);
        $this->pdf->MultiCell(0.15*$pageWidth, 0, Mage::helper('purchase')->__('Sku'), 'B','R', 0, 0, '', '', true);
        $this->pdf->MultiCell(0.6*$pageWidth, 0, Mage::helper('purchase')->__('Product'), 'B', 'R', 0, 0, '', '', true);
        $this->pdf->MultiCell(0.15*$pageWidth, 0, Mage::helper('purchase')->__('Location'), 'B','R', 0, 1, '', '', true);


        foreach ($lines as $line) {
            $page_start = $this->pdf->getPage();
            $y_start = $this->pdf->GetY();
            $product = $line['product'];

            $this->pdf->MultiCell(0.1*$pageWidth, 0, $line['qty'],'B', 'R', 0, 0, '', '', true);
            $page_end_1 = $this->pdf->getPage();
            $y_end_1 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);

            //qty
            $this->pdf->MultiCell(0.15*$pageWidth, 0, $product->getSku(),'B', 'R', 0, 0, '', '', true);
            $page_end_2 = $this->pdf->getPage();
            $y_end_2 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);

            //sku
            $this->pdf->MultiCell(0.6*$pageWidth, 0, $product->getName(),'B', 'R', 0, 0, '', '', true);
            $page_end_3 = $this->pdf->getPage();
            $y_end_3 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);

            //name
            $this->pdf->MultiCell(0.15*$pageWidth, 0, $line['location'], 'B','R', 0, 1, '', '', true);
            $page_end_4 = $this->pdf->getPage();
            $y_end_4 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);

            //new page if required
            $newPage=max($page_end_1,$page_end_2,$page_end_3,$page_end_4);
            if (max($page_end_1,$page_end_2,$page_end_3,$page_end_4) == $page_start) {
                $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4);
            } elseif (max($page_end_1, $page_end_2, $page_end_3, $page_end_4)==min($page_end_1, $page_end_2, $page_end_3, $page_end_4)) {
                $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4);
            } elseif ($page_end_1 > $page_end_2) {
                $ynew = $y_end_1;
            } else {
                $tempArray=array(1=>$page_end_1,
                    2=>$page_end_2,
                    3=>$page_end_3,
                    4=>$page_end_4);
                $key=array_search($newPage,$tempArray);
                $name='y_end_'.$key;
                $ynew = $$name;
            }
            $this->pdf->setPage($newPage);
            $this->pdf->SetXY($this->pdf->GetX(),$ynew);

        }
        return $this->pdf;
    }
}
?>