<?php
class Mage_PDF_Model_Pdf_OrderPreparationCommentsPdf extends MDN_Orderpreparation_Model_Pdf_OrderPreparationCommentsPdf{
    /**
     * @var Mage_All_Helper_Data
     */
    protected $helperMage=null;
    /**
     * @var TCPDF_Extended
     */
    public $pdf;
    protected function __($text){
        if(is_null($this->helperMage)){
            $this->helperMage=Mage::helper('mage_all');
        }
        return $this->helperMage->__($text);
    }
    public function AddAddressesBlock($pdf, $LeftAddress, $RightAddress, $TxtDate, $TxtInfo) {
        //reformate les adresse pour qu'elle tiennent dans la largeur
        //$RightAddress = $this->WrapTextToWidth($page, $RightAddress, 600);
        //barre grise verticale pour s�parer les adresses
        $html=sprintf('<p>%s</p><p>%s</p>',$TxtDate,$TxtInfo);
        $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        $pdf->writeHTMLCell(0, 0, '', '45', '<hr />', 0, 1, 0, true, '', true);
        $pdf->setCellPaddings(1, 3, 1, 3);
        $pdf->setCellMargins(1, 0, 1, 0);
        $pdf->MultiCell(85, 0, $RightAddress, 0, 'R', 0, 0, '', '', true);
        $pdf->MultiCell(85, 0, $LeftAddress, 0, 'R', 0, 1, '', '', true);
        $pdf->writeHTMLCell(0, 0, '', '', '<hr />', 0, 1, 0, true, '', true);
    }

    public function drawTableHeader(&$pdf) {

        //entetes de colonnes
        $header=array(
            array(Mage::helper('purchase')->__('Quantity'),15),
            array(Mage::helper('purchase')->__('Name'),91),
            array(Mage::helper('purchase')->__('Sku'),30),
            array(Mage::helper('purchase')->__('Location'),45)
        );
        $pdf->setCellMargins(0, 0, 0, 0);
        $num_headers=count($header);
        for($i = 0; $i < $num_headers; ++$i) {
            //$pdf->Cell(45, 7, $header[$i], 1, 0, 'C', false);
            $pdf->MultiCell($header[$i][1],7,$header[$i][0],array('T'=>array(1)),'C',0,0);
        }
        $pdf->Ln();
    }
    public function getPdf($order = array()) {
        $this->_beforeGetPdf();
        $this->_initRenderer('invoice');

        if ($this->pdf == null){
            $this->pdf = Tcpdf_Setup::getPDF();
        }else{
            $this->firstPageIndex = $this->pdf->getAliasNbPages();
        }

        $this->_currentOrderId = $order->getincrement_id();

        //cree la nouvelle page
        $titre = mage::helper('purchase')->__('Order #') .': '. $order->getincrement_id();

        /*$this->pdf->setHeaderFont(array('dejavusans', '', 8));
        $this->pdf->SetHeaderData('', 0, $titre);*/
        $txt_order=$titre;

        $this->pdf->SetFont('dejavusans', '', 10);
        $this->pdf->AddPage();
        $style = array(
            'position' => '',
            'align' => 'C',
            'stretch' => false,
            'fitwidth' => true,
            'cellfitalign' => '',
            'hpadding' => 'auto',
            'vpadding' => 'auto',
            'fgcolor' => array(0,0,0),
            'bgcolor' => false, //array(255,255,255),
            'text' => true,
            'font' => 'helvetica',
            'fontsize' => 8,
            'stretchtext' => 4
        );
        $this->pdf->write1DBarcode($order->getincrement_id(), 'C128', '', '', '', 18, 0.4, $style, 'T');
        //cartouche
        $txt_date = $this->__("Date :  ") . mage::helper('core')->formatDate($order->getCreatedAt(), 'long');
        //$txt_order = '';

        //$adresse_fournisseur = Mage::getStoreConfig('sales/identity/address');
        $customer = mage::getmodel('customer/customer')->load($order->getCustomerId());
        $adresse_client = mage::helper('purchase')->__('Shipping Address') . ":\n" . $this->FormatAddress($order->getShippingAddress(), '', false, $customer->gettaxvat());
        $adresse_fournisseur = mage::helper('purchase')->__('Billing Address') . ":\n" . $this->FormatAddress($order->getBillingAddress(), '', false, $customer->gettaxvat());
        $this->AddAddressesBlock($this->pdf, $adresse_fournisseur, $adresse_client, $txt_date, $txt_order);

        //draw comments
        $comments = mage::helper('Orderpreparation/Comments')->getAll($order);
        if (!empty($comments)) {
            $html=sprintf('<p>%s</p><hr />',$comments);
            $this->pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        }
        //Rajoute le carrier et la date d'expe prevue & les commentaires
        $html=sprintf('<p>%s : %s</p>',mage::helper('purchase')->__('Shipping'), $order->getShippingDescription());
        $this->pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        $html=sprintf('<p>%s</p>',$order->getmdn_comments());
        $this->pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);
        $this->pdf->writeHTMLCell(0, 0, '', '', '<hr />', 0, 1, 0, true, '', true);
        //affiche l'entete du tableau
        $this->drawTableHeader($this->pdf);
        //get items
        $preparationWarehouseId = mage::helper('Orderpreparation')->getPreparationWarehouse();
        $operatorId = mage::helper('Orderpreparation')->getOperator();
        $items = Mage::helper('Orderpreparation/Shipment')->GetItemsToShipAsArray($order->getId(), $preparationWarehouseId, $operatorId);

        //if array is empty, include all products
        if (count($items) == 0)
        {
            foreach($order->getAllItems() as $orderItem)
            {
                $items[$orderItem->getId()] = $orderItem->getqty_ordered();
            }
        }

        //SORT BY LOCATION
        if (mage::getStoreConfig('orderpreparation/picking_list/sort_mode') == 'location') {

            //get all locations
            $itemsByLocation = array();
            foreach ($items as $orderItemId => $qty) {
                $itemsByLocation[$orderItemId] =  mage::getModel('sales/order_item')->load($orderItemId)->getShelfLocation();//return "" for product without stock management so OK
            }
            //order them
            if(count($itemsByLocation)>0){
                //order the list by value, so by shelf location
                asort($itemsByLocation);

                //order $items like $itemsByLocation
                $orderedItemsByLocation = array();
                foreach ($itemsByLocation as $orderItemId => $shelflocation) {
                    $orderedItemsByLocation[$orderItemId] = $items[$orderItemId];
                }

                //if operation is sucessfull, replace $item
                if(count($orderedItemsByLocation)>0){
                    $items = $orderedItemsByLocation;
                }
            }
        }


        //Affiche le recap des produits
        //$page->setFillColor(new Zend_Pdf_Color_GrayScale(0.2));
        //$this->defineFont($page,10);
        //becare Full, if they are product bundle or configurable product, simple product can be in double, triple ...
        //this array enble to dispaly item once
        $allreadyDisplayedProducts = array();
        //echo count($items).'<br />';
        foreach ($items as $orderItemId => $qty) {
            if ($qty == 0){
                continue;
            }

            //Load product
            $item = mage::getModel('sales/order_item')->load($orderItemId);
            $productId = $item->getproduct_id();
            $product = mage::getModel('catalog/product')->load($productId);
            if(!in_array($productId, $allreadyDisplayedProducts)){
                $allreadyDisplayedProducts[] = $productId;
            }else{
                //avoid to display many time same product in case of Bundle and configurable
                continue;
            }

            //Does not display products that dont manage stocks
            if (mage::getStoreConfig('orderpreparation/picking_list/display_product_without_stock_management') == 0) {
                if (!$product->getStockItem()->ManageStock()){
                    continue;
                }
            }
            $page_start = $this->pdf->getPage();
            $y_start = $this->pdf->GetY();

            //PICTURE  currently we cannot do anything for it;
            /*$this->pdf->setJPEGQuality(75);
            if ($product->getSmallImage()) {
                $picturePath = Mage::getBaseDir() . DS . 'media' . DS . 'catalog' . DS . 'product' . $product->getSmallImage();
                if (file_exists($picturePath)) {
                    try {
                        //$zendPicture = Zend_Pdf_Image::imageWithPath($picturePath);
                        //$page->drawImage($zendPicture, 10, $this->y - 15, 10 + 30, $this->y - 15 + 30);
                        $this->pdf->MultiCell(30,30,'',array('T'=>array(1)),'C',0,0);
                        $this->pdf->Image($picturePath,150,$y_start,30,30,'JPG', '', '', true, 72, '', false, false, array('T'=>array(1)), false, false, false);
                    } catch (Exception $ex) {
                        mage::logException($ex);
                    }
                }else{
                    //$this->pdf->Cell(30, 0, '', 1, 0, 'C', false);
                    $this->pdf->MultiCell(30,30,'',array('T'=>array(1)),'C',0,0);
                }
            }else{
                $this->pdf->MultiCell(30,30,'',array('T'=>array(1)),'C',0,0);
            }*/
            $page_end_1 = $this->pdf->getPage();
            $y_end_1 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);



            //QTY
            $qtySelected = 0;
            if (!$product->getStockItem()->ManageStock()){
                $qtySelected = $item->getqty_ordered();
            }else{
                if($this->_selectedMode == self::MODE_ALL){
                    $qtySelected = $item->getqty_ordered();
                }else if($this->_selectedMode == self::MODE_ORDER_PREPRATION_NOT_SELECTED_TAB){
                    $qtySelected = $item->getreserved_qty();
                }else if($this->_selectedMode == self::MODE_ORDER_PREPRATION_SELECTED_TAB){
                    $qtySelected = mage::getModel('Orderpreparation/ordertoprepare')->GetTotalAddedQtyForProductForSelectedOrder($productId, $order->getId(), $preparationWarehouseId, $operatorId);
                }else{
                    $qtySelected = $this->_selectedMode;
                }
            }
            $this->pdf->MultiCell(15,0,((string)(int)$qtySelected),array('T'=>array(1)),'R',0,0);
            $page_end_2 = $this->pdf->getPage();
            $y_end_2 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);


            //PARENT
            //add configurable product sku + name above if possible
            $pre='';
            if ($product->gettype_id() == 'simple'){
                $parentIds = Mage::getResourceSingleton('catalog/product_type_configurable')->getParentIdsByChild($item->getproduct_id());
                if(count($parentIds)>0){
                    $productParent = Mage::getModel('catalog/product')->load($parentIds[0]);
                    if($productParent && $productParent->getId()>0) {
                       $pre.=sprintf('%s (%s)', $productParent->getName(), $productParent->getSku())."\r\n";
                    }
                }
            }
            //NAME
            $this->pdf->MultiCell(91,0,$pre.$product->getName(),array('T'=>array(1)),'R',0,0);
            $page_end_3 = $this->pdf->getPage();
            $y_end_3 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);


            //SKU
            $this->pdf->MultiCell(30,0,$product->getSku(),array('T'=>array(1)),'C',0,0);
            $page_end_4 = $this->pdf->getPage();
            $y_end_4 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);


            //SHELF LOCATION
            $this->pdf->MultiCell(45,0,$item->getShelfLocation(),array('T'=>array(1)),'R',0);
            $page_end_5 = $this->pdf->getPage();
            $y_end_5 = $this->pdf->GetY();
            $this->pdf->setPage($page_start);


            // logic

            $newPage=max($page_end_1,$page_end_2,$page_end_3,$page_end_4,$page_end_5);
            if (max($page_end_1,$page_end_2,$page_end_3,$page_end_4,$page_end_5) == $page_start) {
                $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4, $y_end_5);
            } elseif (max($page_end_1, $page_end_2, $page_end_3, $page_end_4, $page_end_5)==min($page_end_1, $page_end_2, $page_end_3, $page_end_4, $page_end_5)) {
                $ynew = max($y_end_1, $y_end_2, $y_end_3, $y_end_4, $y_end_5);
            } elseif ($page_end_1 > $page_end_2) {
                $ynew = $y_end_1;
            } else {
                $tempArray=array(1=>$page_end_1,
                         2=>$page_end_2,
                         3=>$page_end_3,
                         4=>$page_end_4,
                         5=>$page_end_5);
                $key=array_search($newPage,$tempArray);
                $name='y_end_'.$key;
                $ynew = $$name;
            }
            $this->pdf->setPage($newPage);
            $this->pdf->SetXY($this->pdf->GetX(),$ynew);

            continue;



            //BARCODE - EAN
            $barcode = mage::helper('AdvancedStock/Product_Barcode')->getBarcodeForProduct($product);
            if ($barcode) {
                try {
                    $picture = mage::helper('AdvancedStock/Product_Barcode')->getBarcodePicture($barcode);
                    if ($picture) {
                        $zendPicture = $this->pngToZendImage($picture);
                        $page->drawImage($zendPicture, 60, $this->y - 15, 60 + 80, $this->y - 15 + 30);
                    }
                }catch(Exception $ex){
                    mage::logException($ex);
                }
            }


            //SHELF LOCATION
            $page->drawText($item->getShelfLocation(), self::X_POS_SHELF_LOCATION, $this->y, 'UTF-8');






            //COMMENTS
            $this->defineFont($page,8);
            $this->y -= $this->_ITEM_HEIGHT;
            $caption = $this->WrapTextToWidth($page, $item->getcomments(), 300);
            $offset = $this->DrawMultilineText($page, $caption, 200, $this->y, 10, 0.2, 11);
            $this->y -= $offset;

            //CHILDs (optionnal) display child product for configurable or a bundle
            if (mage::getStoreConfig('orderpreparation/picking_list/display_sub_products') == 1) {
                if ($product->gettype_id() == 'bundle' || $product->gettype_id() == 'configurable'){
                    $this->y += 15;
                    foreach ($items as $ssorderItemId => $ssqty) {
                        $ssItem = mage::getModel('sales/order_item')->load($ssorderItemId);
                        if ($ssItem->getparent_item_id() == $orderItemId) {
                            $subProductId = $ssItem->getproduct_id();
                            if($subProductId>0){
                                $subProduct = mage::getModel('catalog/product')->load($subProductId);
                                if($subProduct && $subProduct->getId()>0){
                                    $subProductYshift = 9;
                                    $subProductFontHeigth = 8;
                                    $this->y -= $subProductFontHeigth + $subProductYshift;
                                    $this->defineFont($page,$subProductFontHeigth,self::FONT_MODE_ITALIC);
                                    $page->drawText($this->TruncateTextToWidth($page, $subProduct->getSku(), 70), self::X_POS_SKU, $this->y+$subProductYshift, 'UTF-8');
                                    $name = $this->WrapTextToWidth($page, $ssqty.'x '.$subProduct->getName(), self::X_POS_NAME);
                                    $offset = $this->DrawMultilineText($page, $name, 300, $this->y+$subProductYshift, $subProductFontHeigth, 0.2, 11);
                                    $allreadyDisplayedProducts[] = $subProductId;
                                }
                            }
                        }
                    }
                }
            }


            //LINE between 2 products
            $page->setLineWidth(0.5);
            $page->drawLine(10, $this->y - 4, $this->_BLOC_ENTETE_LARGEUR, $this->y - 4);
            $this->y -= $this->_ITEM_HEIGHT;

            //FOOTER or NEXT PAGE
            if ($this->y < ($this->_BLOC_FOOTER_HAUTEUR + 40)) {
                $this->drawFooter($page);
                $page = $this->NewPage($settings);
                $this->drawTableHeader($page);
            }
        }
        //die('here');
        return $this->pdf;

        //dessine le pied de page
        $this->drawFooter($page);

        //rajoute la pagination
        $this->AddPagination($this->pdf);

        $this->_afterGetPdf();


        return $this->pdf;
    }
}
?>
