<?php
require_once(Mage::getModuleDir('controllers','MDN_Orderpreparation').DS.'PackingController.php');

class Mage_Pdf_PackingController extends MDN_Orderpreparation_PackingController {
    public function downloadShippingLabelFileAction()
    {
        //load invoice
        $orderId = $this->getRequest()->getParam('order_id');
        $orderToPrepare = mage::getModel('Orderpreparation/ordertoprepare')->load($orderId, 'order_id');
        $order = Mage::getModel('sales/order')->load($orderId);
        $carrierTemplate = mage::helper('Orderpreparation/CarrierTemplate')->getTemplateForOrder($order);
        if ($carrierTemplate == null)
        {
            die($this->__('No template file found for this shipping service'));
        }
        else
        {
            $collection = mage::getModel('Orderpreparation/ordertoprepare')
                ->getCollection()
                ->addFieldToFilter('order_id', $orderId);
            $content = $carrierTemplate->createExportFile($collection);
            $data=explode("\r\n",$content);
            foreach($data as &$row){
                $row=explode("\t",$row);
            }
            $data=$data[1];
            require(Mage::getModuleDir('','Mage_PDF').DS.'Helper'.DS.'Addresspdf.php');
            //$fileName = 'order_' . $order->getIncrementId() . '.csv';
            //$this->_prepareDownloadResponse($fileName, $content, 'text/csv');
        }

    }
}