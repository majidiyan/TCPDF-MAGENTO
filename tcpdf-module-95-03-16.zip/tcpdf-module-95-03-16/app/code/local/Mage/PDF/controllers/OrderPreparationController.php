<?php
require_once(Mage::getModuleDir('controllers','MDN_Orderpreparation').DS.'OrderPreparationController.php');

class Mage_Pdf_OrderPreparationController extends MDN_Orderpreparation_OrderPreparationController {
    public function massDownloadPreparationPdfAction() {
        //retrieve order ids from ordertopreparepending ids
        $orderPreparationIds = $this->getRequest()->getPost('full_stock_orders_order_ids');
        $orderIds = array();
        $collection = mage::getModel('Orderpreparation/ordertopreparepending')
            ->getCollection()
            ->addFieldToFilter('opp_num', array('in' => $orderPreparationIds));
        foreach ($collection as $item)
            $orderIds[] = $item->getopp_order_id();

        //load orders collection depending of magento version
        if (mage::helper('AdvancedStock/FlatOrder')->ordersUseEavModel()) {
            $collection = mage::getModel('sales/order')
                ->getCollection()
                ->addFieldToFilter('entity_id', array('in' => $orderIds))
                ->joinAttribute('shipping_firstname', 'order_address/firstname', 'shipping_address_id', null, 'left')
                ->joinAttribute('shipping_lastname', 'order_address/lastname', 'shipping_address_id', null, 'left')
                ->joinAttribute('shipping_company', 'order_address/company', 'shipping_address_id', null, 'left')
                ->addExpressionAttributeToSelect('shipping_name', 'CONCAT({{shipping_firstname}}, " ", {{shipping_lastname}}, " (", {{shipping_company}}, ")")', array('shipping_firstname', 'shipping_lastname', 'shipping_company'));
        } else {
            $collection = mage::getModel('sales/order')
                ->getCollection()
                ->addFieldToFilter('entity_id', array('in' => $orderIds))
                ->join('sales/order_address', '`sales/order_address`.entity_id=shipping_address_id', array('shipping_name' => "concat(firstname, ' ', lastname)"))
            ;
        }

        $pdf = Tcpdf_Setup::getPDF();
        foreach ($collection as $order) {
            $obj = mage::getModel('Orderpreparation/Pdf_OrderPreparationCommentsPdf');
            $obj->pdf = $pdf;
            $otherPdf = $obj->getPdfWithMode($order, MDN_Orderpreparation_Model_Pdf_OrderPreparationCommentsPdf::MODE_ORDER_PREPRATION_NOT_SELECTED_TAB);
            $order->setState(Mage_Sales_Model_Order::STATE_PROCESSING, Mage_PDF_Helper_Data::PICKING, '')->save();

            /*for ($i = 0; $i < count($otherPdf->pages); $i++) {
                //$pdf->pages[] = $otherPdf->pages[$i];
            }*/
        }
        $this->_prepareDownloadResponse('order_preparation.pdf', $pdf->render(), 'application/pdf');
    }
}
